document.getElementById("surpriseBtn").addEventListener("click", function() {
    let surpriseText = document.getElementById("surpriseText");
    surpriseText.innerHTML = "Я тебе дуже-дуже люблю! ❤️";
    surpriseText.style.display = "block";
});
